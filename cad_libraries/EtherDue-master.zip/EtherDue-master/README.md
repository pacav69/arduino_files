# EtherDue

The EtherDue is an 100% Arduino Due compatible board with onboard Ethernet.

For full details about the EtherDue, including a getting started guide, please visit the [Freetronics EtherDue product page](http://www.freetronics.com/products/etherdue-arduino-due-compatible-with-onboard-ethernet).

Design files were produced with [Kicad](http://kicad-pcb.org). A [PDF of the schematic is available](https://github.com/freetronics/EtherDue/raw/master/EtherDue.pdf).

